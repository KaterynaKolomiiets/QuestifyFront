import s from './HomeView.module.css'

const HomeView=()=> {
    return (<></>)
}

export default HomeView