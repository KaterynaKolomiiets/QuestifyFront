import s from './RegisterView.module.css'

const RegisterView = () => {
    return (<></>)
}

export default RegisterView