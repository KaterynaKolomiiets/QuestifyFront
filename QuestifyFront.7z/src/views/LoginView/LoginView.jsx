import s from './LoginView.module.css'

const LoginView=()=> {
    return (<></>)
}

export default LoginView